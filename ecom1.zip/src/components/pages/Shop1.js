import React from 'react';
import {withRouter} from 'react-router-dom';

const Shop1 = (props) => {
    console.log(props);
    return (
        <div>
            hello world
        </div>
    )
}

export default withRouter(Shop1)
